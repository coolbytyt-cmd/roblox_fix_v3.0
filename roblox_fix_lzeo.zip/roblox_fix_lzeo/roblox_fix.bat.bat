@echo off
title Roblox CDN Fixer
setlocal enabledelayedexpansion

:menu
cls
echo ============================================
echo      ROBLOX CDN FIXER - Menu
echo ============================================
echo.

set FIX_STATUS=0
findstr /i "roblox.com" "%windir%\System32\drivers\etc\hosts" >nul 2>&1
if %errorlevel% equ 0 set FIX_STATUS=1

if %FIX_STATUS% equ 1 (
    echo [STATUS] Fix INSTALLED
) else (
    echo [STATUS] Fix NOT INSTALLED
)
echo.
echo ============================================
echo  1 - Install fix
echo  2 - Uninstall fix
echo  3 - Information
echo  4 - Exit
echo ============================================
echo.
set /p choice="Select action (1-4): "

if "%choice%"=="1" goto :install
if "%choice%"=="2" goto :uninstall
if "%choice%"=="3" goto :info
if "%choice%"=="4" exit /b

echo Invalid choice!
timeout /t 2 >nul
goto :menu

:install
cls
echo ============================================
echo      INSTALL FIX
echo ============================================
echo.

net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Run as Administrator!
    pause
    goto :menu
)

if not exist "%windir%\System32\drivers\etc\hosts.backup" (
    copy "%windir%\System32\drivers\etc\hosts" "%windir%\System32\drivers\etc\hosts.backup" >nul
    echo [BACKUP] Created
) else (
    echo [BACKUP] Already exists
)

findstr /v /i "roblox.com rbxcdn.com" "%windir%\System32\drivers\etc\hosts" > "%temp%\hosts_clean.tmp"
copy /y "%temp%\hosts_clean.tmp" "%windir%\System32\drivers\etc\hosts" >nul
del "%temp%\hosts_clean.tmp"
echo [CLEAN] Old records removed

set IP_LIST=18.64.211.78 18.64.211.88 18.64.211.103 18.64.211.77 18.64.211.89 18.64.211.91 18.64.211.92 18.64.211.93 18.64.211.94 18.64.211.96 18.64.211.97 18.64.211.98 18.64.211.99 18.64.211.100

echo.
echo [SCANNING] Checking IPs...
echo.

set FOUND_IPS=
set COUNT=0

for %%i in (%IP_LIST%) do (
    ping -n 1 -w 500 %%i >nul 2>&1
    if !errorlevel! equ 0 (
        echo [OK] %%i - available
        set FOUND_IPS=!FOUND_IPS! %%i
        set /a COUNT+=1
    ) else (
        echo [NO] %%i - unavailable
    )
)

echo.
if %COUNT% equ 0 (
    echo [ERROR] No working IPs!
    pause
    goto :menu
)

echo [RESULT] Found %COUNT% working IPs
echo.

echo [WRITE] Adding to hosts...
echo. >> "%windir%\System32\drivers\etc\hosts"
echo # === ROBLOX CDN FIX (%date% %time%) === >> "%windir%\System32\drivers\etc\hosts"

for %%a in (%FOUND_IPS%) do (
    echo %%a tr.rbxcdn.com >> "%windir%\System32\drivers\etc\hosts"
    echo %%a roblox.com >> "%windir%\System32\drivers\etc\hosts"
    echo %%a rbxcdn.com >> "%windir%\System32\drivers\etc\hosts"
)

echo # === END OF BLOCK === >> "%windir%\System32\drivers\etc\hosts"
echo [WRITE] Done

echo.
echo [ACTION] Flushing DNS...
ipconfig /flushdns >nul
echo [ACTION] DNS flushed

echo [ACTION] Resetting Winsock...
netsh winsock reset >nul
echo [ACTION] Winsock reset

echo.
echo ============================================
echo   FIX INSTALLED SUCCESSFULLY!
echo ============================================
echo.
echo IMPORTANT: Restart PC for changes to take effect.
echo.
pause
goto :menu

:uninstall
cls
echo ============================================
echo      UNINSTALL FIX
echo ============================================
echo.

net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Run as Administrator!
    pause
    goto :menu
)

if not exist "%windir%\System32\drivers\etc\hosts.backup" (
    echo [ERROR] Backup not found!
    echo Fix is not installed or backup deleted.
    pause
    goto :menu
)

echo WARNING! Original hosts will be restored.
echo.
set /p confirm="Uninstall fix? (y/n): "
if /i not "%confirm%"=="y" (
    echo Cancelled.
    pause
    goto :menu
)

copy /y "%windir%\System32\drivers\etc\hosts.backup" "%windir%\System32\drivers\etc\hosts" >nul
echo [RESTORE] hosts restored

ipconfig /flushdns >nul
echo [ACTION] DNS cache flushed

echo.
echo ============================================
echo   FIX UNINSTALLED SUCCESSFULLY!
echo ============================================
pause
goto :menu

:info
cls
echo ============================================
echo      INFORMATION
echo ============================================
echo.
echo ROBLOX CDN FIXER v1.0
echo Author: @lzeo05
echo GitHub: github.com/lzeo05-hub/roblox_fix_2026
echo.
echo What it does:
echo  - Finds working IPs of Roblox servers
echo  - Writes them to system hosts file
echo  - Creates backup of hosts
echo  - Flushes DNS cache and Winsock
echo.
echo Status:
findstr /i "roblox.com" "%windir%\System32\drivers\etc\hosts" >nul 2>&1
if %errorlevel% equ 0 (
    echo   Fix INSTALLED
) else (
    echo   Fix NOT INSTALLED
)
echo.
pause
goto :menu